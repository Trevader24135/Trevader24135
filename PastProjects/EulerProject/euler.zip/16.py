num = 2**1000
numb = []

Sum = 0
for i in range(len(str(num))):
	Sum += int(str(num)[i])
	print(Sum)
print(Sum)